﻿using System.Diagnostics;

class Program
{
    static readonly MemberCollection members = new MemberCollection();
    static readonly MovieCollection movies = new MovieCollection();
    static void Main(string[] args)
    {
   
        while (true)
        {
            Console.Clear();
            Console.WriteLine("===== Community Library DVD System =====");
            Console.WriteLine("1. Staff Login");
            Console.WriteLine("2. Member Login");
            Console.WriteLine("0. Exit");
            Console.Write("Select an option: ");

            string choice = Console.ReadLine() ?? "";
            switch (choice)
            {
                case "1": StaffLogin(); break;
                case "2": MemberLogin(); break;
                case "333": RunEmpiricalAnalysis(); break;
                case "0": return;
                default: Console.WriteLine("Invalid option."); break;
            }
        }
    }
    static void RunEmpiricalAnalysis()
    {
        static long DisplayTopThreeMovies(MovieCollection movies)
        {
            long operations = 0;

            Movie? top1 = null;
            Movie? top2 = null;
            Movie? top3 = null;

            for (int i = 0; i < 1000; i++)
            {
                Movie? current = movies.GetMovieAt(i);
                if (current == null) continue;
                operations++;
                if (top1 == null || current.BorrowCount > top1.BorrowCount)
                {
                    top3 = top2;
                    top2 = top1;
                    top1 = current;
                    operations += 3; // 3 assignments

                }
                else
                {
                    operations++;

                    if (top2 == null || current.BorrowCount > top2.BorrowCount)
                    {
                        top3 = top2;
                        top2 = current;
                        operations += 2; // 2 assignments

                    }

                    else
                    {
                        operations++;
                        if (top3 == null || current.BorrowCount > top3.BorrowCount)
                        {
                            top3 = current;
                        }
                    }
                }
            }

            Console.WriteLine("Top 3 most frequently borrowed movies:");
            if (top1 != null) Console.WriteLine($"{top1.Title} - Borrowed {top1.BorrowCount} times");
            if (top2 != null) Console.WriteLine($"{top2.Title} - Borrowed {top2.BorrowCount} times");
            if (top3 != null) Console.WriteLine($"{top3.Title} - Borrowed {top3.BorrowCount} times");
            return operations;
        }
        for (int size = 100; size <= 1000; size += 100)
        {
            MovieCollection movies = new();
            Random rand = new();

            for (int i = 0; i < size; i++)
            {
                var movie = new Movie($"Movie {i}", Genre.Action, Classification.PG, 90, 3);
                for (int j = 0; j < rand.Next(0, 500); j++) movie.IncrementBorrowCount(); // simulate borrowing
                movies.Add(movie);
            }
            long totalOperations = DisplayTopThreeMovies(movies); 
            ConsoleHelper.Pause($"Input size: {size} — Total operations: {totalOperations} ");
        }
    }
    static void StaffLogin()
    {
        Console.Write("Username: ");
        string user = Console.ReadLine() ?? "";
        Console.Write("Password: ");
        string pass = Console.ReadLine() ?? "";

        if (user == "staff" && pass == "today123")
        {
            // Instantiate StaffMenu and show menu
            StaffMenu staffMenu = new(movies, members);
            staffMenu.ShowMenu();
        }
        else
        {
            Console.WriteLine("Invalid staff credentials.");
            Console.ReadKey();
        }
    }

    static void MemberLogin()
    {
        Console.Write("First Name: ");
        string fname = (Console.ReadLine() ?? "").Trim().ToLowerInvariant();
        Console.Write("Last Name: ");
        string lname = (Console.ReadLine() ?? "").Trim().ToLowerInvariant();
        Console.Write("Password: ");
        string pass = (Console.ReadLine() ?? "").Trim().ToLowerInvariant();

        Member? member = members.Authenticate(fname, lname, pass);
        if (member != null)
        {
            MembersMenu memberMenu = new(movies, members, member);
            memberMenu.ShowMenu();
        }
        else
        {
            Console.WriteLine("Invalid member login.");
            Console.ReadKey();
        }
    }
}

public class StaffMenu(MovieCollection movies, MemberCollection members)
{
    private readonly MovieCollection movies = movies;
    private readonly MemberCollection members = members;

    public void ShowMenu()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("===== Staff Menu =====");
            Console.WriteLine("1. Add DVDs to system");
            Console.WriteLine("2. Remove DVDs from system");
            Console.WriteLine("3. Register a new member to system");
            Console.WriteLine("4. Remove a registered member from system");
            Console.WriteLine("5. Find a member contact phone number, given the member's name");
            Console.WriteLine("6. Find all the members who are currently renting a particular movie.");
            Console.WriteLine("0. Return to main menu");
            Console.Write("Select an option: ");

            string choice = Console.ReadLine() ?? "";
            switch (choice)
            {
                case "1": AddMovie(); break;
                case "2": RemoveMovie(); break;
                case "3": RegisterNewMember(); break;
                case "4": RemoveMember(); break;
                case "5": FindNumberByName(); break;
                case "6": FindMovieBorrowers(); break;
                case "0": return;
                default: Console.WriteLine("Invalid option."); break;
            }
        }
    }

    private void AddMovie()
    {
        {
            Console.Write("Enter movie title: ");
            string title = (Console.ReadLine() ?? "").Trim().ToLowerInvariant();

            Movie? existingMovie = movies.Get(title);
            if (existingMovie != null)
            {
                // Movie already exists
                Console.WriteLine("Movie already exists.");
                Console.Write("Enter number of new copies to add: ");
                if (int.TryParse(Console.ReadLine(), out int copiesToAdd) && copiesToAdd > 0)
                {
                    existingMovie.AddCopies(copiesToAdd);
                    Console.WriteLine("Copies added successfully.");
                }
                else
                {
                    Console.WriteLine("Invalid number entered.");
                }
            }
            else
            {
                // Movie does not exist
                Console.WriteLine("New movie detected.");

                // Display the list
                Console.WriteLine("Select a genre:");
                var genres = Enum.GetValues<Genre>();
                for (int i = 0; i < genres.Length; i++)
                {
                    Console.WriteLine($"{i + 1}. {genres[i]}");
                }

                // User selects a number
                int genreIndex;
                while (true)
                {
                    Console.Write("Enter the number of your choice: ");
                    string input = Console.ReadLine() ?? "";

                    if (int.TryParse(input, out genreIndex) && genreIndex >= 1 && genreIndex <= genres.Length)
                        break;

                    Console.WriteLine("Invalid input. Please enter a valid number.");
                }

                // Now safely get the genre
                Genre genre = genres[genreIndex - 1];


                Console.WriteLine("Select a classification:");
                var classifications = Enum.GetValues<Classification>();
                for (int i = 0; i < classifications.Length; i++)
                {
                    Console.WriteLine($"{i + 1}. {classifications[i]}");
                }

                int classificationIndex;
                while (true)
                {
                    Console.Write("Enter the number of your choice: ");
                    string input = Console.ReadLine() ?? "";

                    if (int.TryParse(input, out classificationIndex) && classificationIndex >= 1 && classificationIndex <= classifications.Length)
                        break;

                    Console.WriteLine("Invalid input. Please enter a valid number.");
                }

                // Now safely get the classification
                Classification classification = classifications[classificationIndex - 1];
                int duration;
                while (true)
                {
                    Console.Write("Enter duration in minutes: ");
                    string input = Console.ReadLine() ?? "";
                    if (int.TryParse(input, out duration) && duration > 0)
                        break;
                    Console.WriteLine("Invalid input. Please enter a positive number.");
                }

                int copies;
                while (true)
                {
                    Console.Write("Enter number of copies: ");
                    string input = Console.ReadLine() ?? "";
                    if (int.TryParse(input, out copies) && copies >= 0)
                        break;
                    Console.WriteLine("Invalid input. Please enter 0 or a positive number.");
                }

                Movie newMovie = new(title, genre, classification, duration, copies);
                bool success = movies.Add(newMovie);

                if (success)
                    Console.WriteLine("New movie added successfully!");
                else
                    Console.WriteLine("Failed to add movie (maybe the collection is full?).");
            }
        }
    }
    private void RemoveMovie()
    {
        Console.Write("Enter movie title to remove: ");
        string title = (Console.ReadLine() ?? "").Trim().ToLowerInvariant();

        Movie? movie = movies.Get(title);
        if (movie == null)
        {
            ConsoleHelper.Pause("Movie not found.");
            return;
        }

        while (true)
        {
            Console.Write($"Enter number of copies to remove (available: {movie.Copies}, or 'x' to cancel): ");
            string input = Console.ReadLine()?.Trim() ?? "";

            if (input?.ToLower() == "x")
            {
                Console.WriteLine("Operation cancelled.");
                break;
            }

            if (int.TryParse(input, out int copiesToRemove) && copiesToRemove > 0)
            {
                bool result = movie.RemoveCopies(copiesToRemove, movies);
                if (result)
                {
                    if (movie.Copies == 0)
                    {
                        ConsoleHelper.Pause($"All copies removed. Movie deleted from the collection. {movie.Copies} copies left in the system.");
                        return;
                    }
                    else
                    {
                        ConsoleHelper.Pause("Copies removed successfully.");
                        return;
                    }
                }
                else
                {
                    Console.WriteLine("Cannot remove more copies than available. Try again.");
                }
            }
            else
            {
                Console.WriteLine("Invalid number entered. Try again.");
            }
        }
    }
    private void RegisterNewMember()
    {
        string firstName;
        do
        {
            Console.Write("Enter First Name: ");
            firstName = (Console.ReadLine() ?? "").Trim().ToLowerInvariant();
        } while (string.IsNullOrWhiteSpace(firstName));

        string lastName;
        do
        {
            Console.Write("Enter Last Name: ");
            lastName = (Console.ReadLine() ?? "").Trim().ToLowerInvariant();
        } while (string.IsNullOrWhiteSpace(lastName));

        // Check if member already exists
        if (members.Find(firstName, lastName) != null)
        {
            ConsoleHelper.Pause("Member already registered.");
            return;
        }

        string phoneNumber;
        do
        {
            Console.Write("Enter Phone Number (10 digits only): ");
            phoneNumber = Console.ReadLine()?.Trim() ?? "";

            if (string.IsNullOrWhiteSpace(phoneNumber) || !IsValidPhoneNumber(phoneNumber))
            {
                Console.WriteLine("Invalid phone number. It must be exactly 10 digits and contain only numbers (no spaces or special characters).");
            }

        } while (string.IsNullOrWhiteSpace(phoneNumber) || !IsValidPhoneNumber(phoneNumber));


        Console.WriteLine($"Phone number '{phoneNumber}' is valid.");
        
        string password;
        while (true)
        {
            Console.Write("Set a 4-digit numeric password: ");
            password = Console.ReadLine()?.Trim() ?? "";

            if (password != null && password.Length == 4 && password.All(char.IsDigit))
                break;

            Console.WriteLine("Invalid password. Must be exactly 4 digits.");
        }

        var newMember = new Member(firstName, lastName, phoneNumber, password);
        var addResult = members.Add(newMember);
        if (addResult == AddMemberResult.Success)
            Console.WriteLine("Member registered successfully.");
        else if (addResult == AddMemberResult.Duplicate)
            Console.WriteLine("Failed to register member : member already exists.");
        else Console.WriteLine($"Failed to register member: member capacity exceeded (max {MemberCollection.MaxMembers}");
        Console.WriteLine("Press any key to return...");
        Console.ReadKey();
    }
    public void RemoveMember()
    {
        string firstName, lastName;
        do
        {
            Console.Write("Enter the first name of the member to remove: ");
            firstName = (Console.ReadLine() ?? "").Trim().ToLowerInvariant();
            if (string.IsNullOrWhiteSpace(firstName))
            {
                Console.WriteLine("First name cannot be empty. Please try again.");
            }
        } while (string.IsNullOrWhiteSpace(firstName));

        // Validate last name
        do
        {
            Console.Write("Enter the last name of the member to remove: ");
            lastName = (Console.ReadLine() ?? "").Trim().ToLowerInvariant();
            if (string.IsNullOrWhiteSpace(lastName))
            {
                Console.WriteLine("Last name cannot be empty. Please try again.");
            }
        } while (string.IsNullOrWhiteSpace(lastName));

        Member? memberToRemove = members.Find(firstName, lastName);

        if (memberToRemove == null)
        {
            ConsoleHelper.Pause("Member not found.");
            return;
        }

        // Check if the member has borrowed DVDs
        if (memberToRemove.HasBorrowedAnyMovies())
        {
            Console.WriteLine("Member cannot be removed because they still have borrowed DVDs.");
            ConsoleHelper.Pause("Please ask them to return all DVDs before removing them from the system.");
            return;
        }

        // If no DVDs are borrowed, remove the member
        if (members.Remove(firstName, lastName))
        {
            ConsoleHelper.Pause("Member removed successfully.");
        }
        else
        {
            ConsoleHelper.Pause("Failed to remove the member.");
        }

    }
    private void FindNumberByName()
        {
        {
            string firstName, lastName;

            // Validate first name
            do
            {
                Console.Write("Enter the first name of the member: ");
                firstName = (Console.ReadLine() ?? "").Trim().ToLowerInvariant();
                if (string.IsNullOrWhiteSpace(firstName))
                {
                    Console.WriteLine("First name cannot be empty. Please try again.");
                }
            } while (string.IsNullOrWhiteSpace(firstName));

            // Validate last name
            do
            {
                Console.Write("Enter the last name of the member: ");
                lastName = (Console.ReadLine() ?? "").Trim().ToLowerInvariant();
                if (string.IsNullOrWhiteSpace(lastName))
                {
                    Console.WriteLine("Last name cannot be empty. Please try again.");
                }
            } while (string.IsNullOrWhiteSpace(lastName));

            // Find the member
            Member? member = members.Find(firstName, lastName);

            if (member != null)
            {
                ConsoleHelper.Pause($"The contact phone number for {firstName} {lastName} is: {member.PhoneNumber}");
            }
            else
            {
                ConsoleHelper.Pause("Member not found.");
            }

        }
    }

    private void FindMovieBorrowers()
        {
        Console.Write("Enter the movie title: ");
        string title = Console.ReadLine()?.Trim().ToLower() ?? "";

        bool anyBorrowers = false;

        for (int i = 0; i < MemberCollection.MaxMembers; i++)
        {
            Member? member = members.GetMemberAt(i);
            if (member != null && member.HasBorrowed(title))
            {
                if (!anyBorrowers)
                {
                    Console.WriteLine($"Members currently borrowing \"{title}\":");
                    anyBorrowers = true;
                }

                Console.WriteLine($" - {member.FirstName} {member.LastName} (Phone: {member.PhoneNumber})");
            }
        }

        if (!anyBorrowers)
        {
            Console.WriteLine($"No members are currently borrowing \"{title}\".");
        }
    }

    public static bool IsValidPhoneNumber(string phoneNumber)
    {
        // Check if phone number has exactly 10 digits and contains only numbers
        if (phoneNumber.Length != 10)
            return false;

        foreach (char c in phoneNumber)
        {
            if (!char.IsDigit(c))  // Ensure each character is a digit
                return false;
        }

        return true;
    }
}

public class MembersMenu(MovieCollection movies, MemberCollection members, Member member)
{
    private readonly MovieCollection movies = movies;
    private readonly MemberCollection members = members;
    private readonly Member member = member;
    public void ShowMenu()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("===== Members Menu =====");
            Console.WriteLine("1. Browse all the movies");
            Console.WriteLine("2. Display all the informations about a movie, given the title of the movie");
            Console.WriteLine("3. Borrow a movie DVD");
            Console.WriteLine("4. Return a movie DVD");
            Console.WriteLine("5. List current borrowing movies");
            Console.WriteLine("6. Display the top 3 movies rented by the members.");
            Console.WriteLine("0. Return to main menu");
            Console.Write("Select an option: ");

            string choice = Console.ReadLine() ?? "";
            switch (choice)
            {
                case "1": DisplayAllMoviesInOrder(); break;
                case "2": DisplayMovieInfos(); break;
                case "3": BorrowMovie(); break;
                case "4": ReturnMovie(); break;
                case "5": ListBorrowedMoviesByUser(); break;
                case "6": DisplayTopThreeMovies(); break;
                case "0": return;
                default: Console.WriteLine("Invalid option."); break;
            }
        }
    }
    public void DisplayAllMoviesInOrder()
    {

        const int Capacity = 1000;
        Movie[] allMovies = new Movie[Capacity];
        int count = 0;

        // Collect all movies
        for (int i = 0; i < Capacity; i++)
        {
            Movie? movie = movies.GetMovieAt(i);
            if (movie != null)
            {
                allMovies[count++] = movie;
            }
        }

        for (int i = 0; i < count - 1; i++)
        {
            for (int j = 0; j < count - i - 1; j++)
            {
                if (string.Compare(allMovies[j].Title, allMovies[j + 1].Title, StringComparison.OrdinalIgnoreCase) > 0)
                {
                    (allMovies[j + 1], allMovies[j]) = (allMovies[j], allMovies[j + 1]);
                }
            }
        }

        // Display movies
        int totalCopies = 0;
        Console.WriteLine("Movies in the library (sorted by title):");
        for (int i = 0; i < count; i++)
        {
            Console.WriteLine(allMovies[i]); 
            totalCopies += allMovies[i].Copies;
        }

        ConsoleHelper.Pause($"\nTotal number of DVD copies in the library: {totalCopies}");
    }

    public void DisplayMovieInfos()
    {
        Console.Write("Enter the title of the movie: ");
        string title = (Console.ReadLine() ?? "").Trim().ToLowerInvariant();


        Movie? movie = movies.Get(title);
        if (movie != null)
        {
            Console.WriteLine("Movie details:");
            ConsoleHelper.Pause(movie.ToString()); 
        }
        else
        {
            Console.WriteLine("Movie not found in the library.");
        }
    }
    
    public void BorrowMovie()
    {
        Console.Write("Enter movie title to borrow: ");
        string title = (Console.ReadLine() ?? "").Trim().ToLowerInvariant();

        Movie? movie = movies.Get(title);
        if (movie == null)
        {
            Console.WriteLine("Movie not found.");
            return;
        }

        if (movie.Copies == 0)
        {
            Console.WriteLine("No copies available to borrow.");
            return;
        }

        if (member.BorrowMovie(title))
        {
            movie.Copies--; 
            movie.IncrementBorrowCount();
            ConsoleHelper.Pause("Movie borrowed successfully.");
        }
        else
        {
            ConsoleHelper.Pause("Could not borrow movie. Maybe already borrowed or limit reached.");
        }
    }

    public void ReturnMovie()
    {
        Console.Write("Enter movie title to return: ");
        string title = (Console.ReadLine() ?? "").Trim().ToLowerInvariant();


        Movie? movie = movies.Get(title);
        if (movie == null)
        {
            Console.WriteLine("Movie not found.");
            return;
        }

        if (member.ReturnMovie(title))
        {
            movie.Copies++; // Increase available copies
            ConsoleHelper.Pause("Movie returned successfully.");
        }
        else
        {
            ConsoleHelper.Pause("You did not borrow this movie.");
        }
    }
    public void ListBorrowedMoviesByUser()
    {
        Console.WriteLine("Movies currently being borrowed by members:\n");

        for (int i = 0; i < MemberCollection.MaxMembers; i++)
        {
            Member? member = members.GetMemberAt(i); // We need to access each member in the collection
            if (member != null && member.HasBorrowedAnyMovies())
            {
                member.DisplayBorrowedMovies();
                Console.WriteLine(); // Line break between members
            }
        }
        ConsoleHelper.Pause("Done !");
    }

    public void DisplayTopThreeMovies()
    {
        Movie? top1 = null;
        Movie? top2 = null;
        Movie? top3 = null;

        for (int i = 0; i < 1000; i++)
        {
            Movie? current = movies.GetMovieAt(i);
            if (current == null) continue;

            if (top1 == null || current.BorrowCount > top1.BorrowCount)
            {
                top3 = top2;
                top2 = top1;
                top1 = current;
            }
            else if (top2 == null || current.BorrowCount > top2.BorrowCount)
            {
                top3 = top2;
                top2 = current;
            }
            else if (top3 == null || current.BorrowCount > top3.BorrowCount)
            {
                top3 = current;
            }
        }

        Console.WriteLine("Top 3 most frequently borrowed movies:");
        if (top1 != null) Console.WriteLine($"{top1.Title} - Borrowed {top1.BorrowCount} times");
        if (top2 != null) Console.WriteLine($"{top2.Title} - Borrowed {top2.BorrowCount} times");
        if (top3 != null) Console.WriteLine($"{top3.Title} - Borrowed {top3.BorrowCount} times");
    }

}



public enum Genre
{
    Drama,
    Adventure,
    Family,
    Action,
    SciFi,
    Comedy,
    Animated,
    Thriller,
    Other
}

public enum Classification
{
    G,
    PG,
    M15Plus,
    MA15Plus
}
public enum AddMemberResult
{
    Success,
    Duplicate,
    CollectionFull
}
public static class ConsoleHelper
{
    public static void Pause(string message)
    {
        Console.WriteLine(message);
        Console.WriteLine("Press any key to return...");
        Console.ReadKey();
    }
}
public class Movie(string title, Genre genre, Classification classification, int duration, int copies)
{
    public string Title { get; set; } = title;
    public Genre Genre { get; set; } = genre;
    public Classification Classification { get; set; } = classification;
    public int Duration { get; set; } = duration;
    public int Copies { get; set; } = copies;

    public int BorrowCount { get; private set; } = 0;

    public void IncrementBorrowCount()
    {
        BorrowCount++;
    }

    public override string ToString()
    {
        return $"{Title} - {Genre}, {Classification}, {Duration} mins, {Copies} copies";
    }

    public void AddCopies(int copies)
    {
        Copies += copies;
    }
    public bool RemoveCopies(int copies, MovieCollection movieCollection)
    {
        int newCopies = Copies - copies;
        if (newCopies > 0)
        {
            Copies = newCopies;
        }
        else if (newCopies == 0)
        {
            Copies = 0;
            movieCollection.Remove(Title);
        }
        else return false;

        return true;
    }
}

public class MovieCollection
{
    public const int Capacity = 1000;

    private string?[] keys = new string[Capacity];
    private Movie?[] values = new Movie[Capacity];

    public MovieCollection() { }
    public Movie? GetMovieAt(int index)
    {
        if (index >= 0 && index < Capacity)
            return values[index];
        return null;
    }
    private static int Hash(string key)
    {
        int hash = 0;
        foreach (char c in key)
        {
            hash = (hash * 31 + c) % Capacity;
        }
        return hash;
    }

    public bool Add(Movie movie)
    {
        string key = movie.Title;
        int index = Hash(key);

        for (int i = 0; i < Capacity; i++)
        {
            int probeIndex = (index + i) % Capacity;

            if (keys[probeIndex] == null || keys[probeIndex] == key)
            {
                keys[probeIndex] = key;
                values[probeIndex] = movie;
                return true;
            }
        }

        return false; // Table full
    }

    public Movie? Get(string title)
    {
        int index = Hash(title);

        for (int i = 0; i < Capacity; i++)
        {
            int probeIndex = (index + i) % Capacity;
            if (keys[probeIndex] == null)
                return null;
            if (keys[probeIndex] == title)
                return values[probeIndex];
        }

        return null;
    }

    public bool Remove(string title)
    {
        int index = Hash(title);

        for (int i = 0; i < Capacity; i++)
        {
            int probeIndex = (index + i) % Capacity;
            if (keys[probeIndex] == null)
                return false;
            if (keys[probeIndex] == title)
            {
                keys[probeIndex] = null;
                values[probeIndex] = null;
                return true;
            }
        }

        return false;
    }

    public void DisplayAll()
    {
        for (int i = 0; i < Capacity; i++)
        {
            if (keys[i] != null)
            {
                Console.WriteLine(values[i]);
            }
        }
    }
}


public class Member(string firstName, string lastName, string phoneNumber, string password)
{
    public string FirstName { get; } = firstName;
    public string LastName { get; } = lastName;
    public string PhoneNumber { get; } = phoneNumber;
    public string Password { get; } = password;

    private const int MaxBorrowed = 5;
    private readonly string?[] borrowedTitles = new string[MaxBorrowed];

    public bool BorrowMovie(string title)
    {
        if (HasBorrowed(title))
            return false; // Already borrowed this movie

        for (int i = 0; i < MaxBorrowed; i++)
        {
            if (borrowedTitles[i] == null)
            {
                borrowedTitles[i] = title;
                return true;
            }
        }

        return false; // No space left
    }
    public bool HasBorrowedAnyMovies()
    {
        return Array.Exists(borrowedTitles, title => title != null);
    }
    public bool ReturnMovie(string title)
    {
        for (int i = 0; i < MaxBorrowed; i++)
        {
            if (borrowedTitles[i] == title)
            {
                borrowedTitles[i] = null;
                return true;
            }
        }

        return false;  
    }

    public bool HasBorrowed(string title)
    {
        for (int i = 0; i < MaxBorrowed; i++)
        {
            if (borrowedTitles[i] == title)
                return true;
        }

        return false;
    }

    public void DisplayBorrowedMovies()
    {
        Console.WriteLine($"{FirstName} {LastName} borrowed:");
        for (int i = 0; i < MaxBorrowed; i++)
        {
            if (borrowedTitles[i] != null)
                Console.WriteLine($" - {borrowedTitles[i]}");
        }
    }

    public override string ToString()
    {
        return $"{FirstName} {LastName} - Phone: {PhoneNumber}";
    }
}


public class MemberCollection
{
    public const int MaxMembers = 1000;
    private readonly Member?[] members = new Member[MaxMembers];
    private int count = 0;
    public AddMemberResult Add(Member member)
    {
        if (count >= MaxMembers)
            return AddMemberResult.CollectionFull;

        if (Find(member.FirstName, member.LastName) != null)
            return AddMemberResult.Duplicate; // Duplicate

        members[count++] = member;
        return AddMemberResult.Success;
    }

    public Member? Find(string firstName, string lastName)
    {
        for (int i = 0; i < count; i++)
        {

            if (members[i]?.FirstName == firstName && members[i]?.LastName == lastName)
                return members[i];
        }

        return null;
    }

    public bool Remove(string firstName, string lastName)
    {
        for (int i = 0; i < count; i++)
        {
            if (members[i]?.FirstName == firstName && members[i]?.LastName == lastName)
            {
                // Shift elements to left
                for (int j = i; j < count - 1; j++)
                {
                    members[j] = members[j + 1];
                }
                members[count - 1] = null;
                count--;
                return true;
            }
        }

        return false;
    }

    public Member? GetMemberAt(int index)
    {
        if (index >= 0 && index < count)
            return members[index];
        return null;
    }

    public Member? Authenticate(string firstName, string lastName, string password)
    {
        for (int i = 0; i < count; i++)
        {
            if (members[i]?.FirstName == firstName &&
                members[i]?.LastName == lastName &&
                members[i]?.Password == password)
            {
                return members[i];
            }
        }

        return null;
    }
}
