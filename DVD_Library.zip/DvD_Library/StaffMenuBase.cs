﻿public class StaffMenuBase
{
}