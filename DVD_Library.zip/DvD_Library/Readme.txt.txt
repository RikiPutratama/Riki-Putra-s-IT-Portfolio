Community Library DVD System by:

Andhika Putratama N11434457

Phukhao Pimgoson N11531231

Group 38



A console-based application in C# to help manage DVD rentals for a local community. The system supports staff and members, each with their own set of features for managing and interacting with the DVD collection.
 Features
 Staff Features

    Add, delete, and update DVD information.

    Register and remove members.

    Look up a member’s phone number.

    View all members who borrowed a particular DVD.

 Member Features (via MembersMenu)

    Browse All Movies — Lists all DVDs in alphabetical order.

    View Movie Details — Get full information about a movie by title.

    Borrow DVD — Borrow a DVD if copies are available.

    Return DVD — Return a previously borrowed DVD.

    View Borrowed DVDs — See all DVDs currently borrowed by members.

    Top 3 Rented DVDs — Display the top 3 most borrowed movies of all time.

 Hidden Feature

    Enter 333 at the main menu to perform an empirical analysis, showing the top 3 most rented movies from large datasets for benchmarking and testing.

 How to Run
    Open the solution in Visual Studio 2022.

    Make sure the target framework is .NET 8.0.

    Build and run the solution.

    Follow the on-screen prompts in the console interface.

 Login Credentials

    Staff

        Username: staff

        Password: today123

    Member

        Must enter first name, last name, and password as previously registered by staff.

